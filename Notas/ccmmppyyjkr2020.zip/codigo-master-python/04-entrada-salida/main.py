# Entrada
nombre = input("¿Cual es tu nombre?: ")
edad = input("¿Cual es tu edad?: ")

# Salida
print(f"Me alegro de conocerte, bienvenido {nombre}, veo que tienes {int(edad) + 2} años!!")