def nombreCompleto(nombre, apellidos):
    print(f"{nombre} {apellidos}")