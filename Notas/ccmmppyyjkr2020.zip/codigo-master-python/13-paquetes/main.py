print("PROBANDO PAQUETES:")

from mipaquete import pruebas, herramientas

pruebas.probando()
herramientas.nombreCompleto("Víctor", "Robles")