from django.apps import AppConfig


class MiappConfig(AppConfig):
    name = 'miapp'
    verbose_name = 'Mi primera aplicación'
