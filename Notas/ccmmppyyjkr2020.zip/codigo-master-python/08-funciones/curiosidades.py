def mi_funcion(nombre):
    return "Hola que tal " + nombre

def mi_segunda_funcion(apellidos):
    return "Hola que tal 2" + apellidos

nombre = "Víctor"
apellidos = "Robles"

print(mi_funcion(nombre))
print(mi_segunda_funcion(apellidos))
