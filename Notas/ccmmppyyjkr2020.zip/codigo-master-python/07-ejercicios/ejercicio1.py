"""
Ejercicio 1.
    - Crear variables una "pais" y otra "continente"
    - Mostrar su valor por pantalla (imprimir)
    - Poner un comentario diciendo el tipo de dato    
"""

pais = "España"        #string
continente = "Europa"  #string
year = 2021            #integer

print(f"{pais} - {continente} - {str(year)}")