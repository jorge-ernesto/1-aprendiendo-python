# Esto me mostrará el texto Hola por la consola
print("Hola")

# Estas dos instrucciones muestran texto por pantalla
print("Mundo")
# print("!!")

"""
Esto no se mostrará:
    print("Esto no se va a mostrar")
    print("Porque estará dentro de un comentario multilinea")
"""

print("Adiós!!")