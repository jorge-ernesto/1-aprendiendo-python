print("Hola Mundo !! Soy Victor Robles el profesor del Master en Python")
