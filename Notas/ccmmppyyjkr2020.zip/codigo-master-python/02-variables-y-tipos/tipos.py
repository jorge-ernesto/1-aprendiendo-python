nada = None
cadena = "Hola soy Víctor Robles WEB"
cadena = "Desarrollador web"
entero = 99
flotante = 4.2
booleano = False
lista = [10, 20, 30, 100, 200]
listaString = [44, "treinta", 30, "cuarenta"]
tuplaNoCambia = ("master", "en", "python")
diccionario = {
    "nombre": "Víctor",
    "apellido": "Robles",
    "curso": "Master en Python"
}
rango = range(9)
dato_byte = b"Probando"

# imprimir variable
print(dato_byte)

# mostrar tipo de dato
print(type(dato_byte))

# convertir datos
texto = "Hola soy un texto"
numerito = str(776)
print(type(numerito))
# 776
# "776"
print(texto + " " + numerito)

numerito = int(776)
print(type(numerito))

numerito = float(776)
print(numerito)
