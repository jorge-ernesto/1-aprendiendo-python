# Operadores aritmeticos
numero1 = 80
numero2 = 4 # operador asignación =

resta = numero1 - numero2
multiplicacion = numero1 * numero2
division = numero1 / numero2
resto = numero1 % numero2

print("*********** CALCULADORA *************")
print(f"La suma es: {numero1 + numero2}")
print(f"La resta es: {resta}")
print("La multiplicación es: ", multiplicacion)
print("La división es: ", division)
print("El resto de la división es: ", resto)