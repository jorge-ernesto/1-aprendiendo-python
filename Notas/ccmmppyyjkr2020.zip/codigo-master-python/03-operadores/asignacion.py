# Operadores de asignacion
edad = 55

print(edad)

edad += 5
edad = edad + 5
edad -= 5
print(edad)

# Operadores incremento y decremento
year = 2021

# Incremento
#year = year + 1
year += 1

# Decremento
#year = year - 1
year -= 1

# Pre incremento
year = 1 + year

# Pre decremento
year = 1 - year

print(year)
"""
year++
year--
--year
++year
"""